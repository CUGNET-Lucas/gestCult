import sqlite3

class dbDump():
    def rebuildBDD(self, db_path):
        try:
            co = sqlite3.connect(db_path, isolation_level=None, timeout=10)
            co.execute("""
                CREATE TABLE IF NOT EXISTS "rem" (
                "idTech"	INTEGER,
                FOREIGN KEY("idTech") REFERENCES "technicien"("id")
                );""")
            co.execute("""
                CREATE TABLE IF NOT EXISTS "culture" (
                "code"	TEXT,
                "libelle"	TEXT NOT NULL,
                PRIMARY KEY('code')
                );""")
            co.execute("""
                CREATE TABLE IF NOT EXISTS "parcelle" (
                "codeExploitation"	TEXT,
                "idAnnee"	TEXT,
                "id"	INTEGER,
                "surface"	NUMERIC(8, 2) NOT NULL,
                "rendementPrevu"	NUMERIC(9, 2) NOT NULL,
                "rendementRealise"	NUMERIC(9, 2) NOT NULL,
                "codeCulture"	TEXT NOT NULL,
                FOREIGN KEY("codeCulture") REFERENCES "culture"("code"),
                PRIMARY KEY('codeExploitation','idAnnee','id')
                );""")
            co.execute("""
                CREATE TABLE IF NOT EXISTS "technicien" (
                "id"	INTEGER,
                "nom"	TEXT NOT NULL,
                "prenom"	TEXT NOT NULL,
                "matricule"	TEXT NOT NULL UNIQUE,
                "mdp"	TEXT,
                PRIMARY KEY('id')
                );""")
            co.execute("""
                INSERT INTO 'culture'('code','libelle')VALUES ('CE645','maïs');""")
            co.execute("""
                INSERT INTO 'culture'('code','libelle')VALUES ('CE666','blé');""")
            co.execute("""
                INSERT INTO 'culture'('code','libelle')VALUES ('FG743','chanvre');
                """)
            co.execute("""
                INSERT INTO "technicien" VALUES (1,'CUGNET','Lucas','AZ123','$2b$12$MxCvNdaIikZNB4GR9dPiP.iCoUVc0/pAnbO930LF3ftlw6QRzxYOS');
                """)
            co.execute("""
                INSERT INTO "technicien" VALUES (2,'SLAVE','Miro','RU345','$2b$12$zlM5lFSRjSJntbMw.BVzfuxEXqjcER6lSWnJCBhCdWIj8DBTgUfZy');
                """)
            co.close()
        except sqlite3.DatabaseError as err:
            print(err)
        co.close()