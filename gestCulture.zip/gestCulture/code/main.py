import kivy #android and views
import sqlite3 #local database
import re #for string recup between brackets
import bcrypt #for hashing and salting passwords
from kivy.config import Config
from kivymd.app import MDApp
from kivy.utils import platform
from datetime import datetime
from kivymd.uix.screenmanager import MDScreenManager
from kivymd.uix.screen import MDScreen
import os.path #to know on which type of devices is running the app
from senderReceiver import SenderReceiver #class to send datas to php
from rebuildDB import dbDump #class to rebuild the database in case it's missing
kivy.require('2.1.0') #kivy version
#important: le timeout a 10 s permet de fermer les précedentes connections sqlite, sans quoi une erreure survient

if platform != 'android' and platform != 'ios' : #indication de la localisation de la base locale en fonction de la plateform
    Config.set('graphics', 'width', '270') #def d'un format smartphone sur l'application pc
    Config.set('graphics', 'height', '600')
    Config.write()
    db_path = 'baseSQLite.db' #chemin d'accès bdd locale
else:
    package_dir = os.path.abspath(os.path.dirname(__file__)) #recupération du chemin des fichiers de l'app
    db_path = os.path.join(package_dir, 'baseSQLite.db') #chemin de la bdd locale
if not os.path.isfile("baseSQLite.db"): #verification de l'existence de la bdd sinon:
    baseBuilder = dbDump() #instanciation d'un objet dbDump
    baseBuilder.rebuildBDD(db_path) #création de la bdd locale 
    #print("is not created")

class LoginTech(MDScreen):#___________________________________________________________________________/\
    def __init__(self, **kwargs):#a la création
        super(LoginTech, self).__init__(**kwargs)
        self.matricule = ""
        self.id = ""
        self.techInBase = False

    def on_enter(self, *args):#a l'entree
        conn = sqlite3.connect(db_path, isolation_level=None, timeout=10)
        stmt = conn.execute("SELECT * FROM rem")
        idTech = stmt.fetchone()
        if idTech != None:
            stmt = conn.execute("SELECT matricule FROM technicien WHERE id="+str(idTech[0]))
            rows = stmt.fetchall()
            for row in rows:
                if row[0] != "":
                    self.matricule = row[0]
                    self.checkRemember.active = True
                    #self.techInBase = True ancien
            self.matInput.text = self.matricule
        conn.close()
        return super().on_enter(*args)
    
    def clearInput(self, idInput):# vider le text input
        req = 'self.'+idInput+'.select_all()'
        req2 = 'self.'+idInput+'.delete_selection(from_undo=False)'
        exec(req)
        exec(req2)

    def showMdp(self):
        pw = self.mdpInput.password
        if pw == True:
            self.mdpInput.password = False
        else:
            self.mdpInput.password = True


    def connectApp(self):# bouton de connexion
        self.matricule = self.matInput.text
        self.mdp = self.mdpInput.text
        matReg = re.search(r"^([A-Z]|[0-9]){5}$", self.matricule)
        mdpReg = re.search(r"(\'|\"|\`|\<|\>)+", self.mdp)
        if matReg != None:
            if mdpReg == None and self.mdp != '' and self.mdp != None:
                conn = sqlite3.connect(db_path, isolation_level=None, timeout=10)
                try:
                    stmt = conn.execute("SELECT id,mdp FROM technicien WHERE matricule= '"+self.matricule+"';")
                except sqlite3.DatabaseError as err:
                    print(err)
                else:
                    user = stmt.fetchone()
                    if user != None:
                        idUser = user[0]
                        mdpUser = user[1]
                        if self.check_password(self.mdp, mdpUser):
                            if self.checkRemember.active == True:
                                conn = sqlite3.connect(db_path, isolation_level=None, timeout=10)
                                try:
                                    conn.execute("DELETE FROM rem;")
                                    conn.execute("INSERT INTO rem('idTech') VALUES('"+str(idUser)+"');")
                                except sqlite3.DatabaseError as err:
                                    print(err)
                                conn.close()
                            else:
                                conn = sqlite3.connect(db_path, isolation_level=None, timeout=10)
                                try:
                                    conn.execute("DELETE FROM rem")
                                    conn.commit()
                                except sqlite3.DatabaseError as err:
                                    print(err)
                                conn.close()
                            self.err.text = ""
                            self.manager.current = 'accueil'
                        else:
                            self.err.text = "mot de passe erroné"
                    else:
                        self.err.text = "matricule inconnu"
                    conn.close()
            else:
                self.err.text = "Format mdp incorrect"
        else:
            self.err.text = "matricule incorrect"

    def get_hashed_password(self, plain_text_password):
    # Hash a password for the first time
    #   (Using bcrypt, the salt is saved into the hash itself)
        return bcrypt.hashpw(plain_text_password.encode('utf-8'), bcrypt.gensalt())

    def check_password(self, plain_text_password, hashed_password):
        # Check hashed password. Using bcrypt, the salt is saved into the hash itself
        return bcrypt.checkpw(plain_text_password.encode('utf-8'), hashed_password.encode('utf-8'))


class Accueil(MDScreen):#___________________________________________________________________________/\
    def __init__(self, **kw):
        super(Accueil, self).__init__(**kw)
    
    def on_pre_enter(self, *args):
        matricule = self.manager.get_screen("connexion").ids.matInput.text
        self.matriculeLabel.text = 'mat: '+matricule
        return super().on_pre_enter(*args)
    
    def backToConnexion(self):
        self.manager.transition.direction = 'right'
        self.manager.current = 'connexion'

    def Saisie(self):
        self.manager.transition.direction = 'left'
        self.manager.current = 'ajoutP'
    
    def Envoie(self):
        self.err.text = 'Chargement'
        try:
            co = sqlite3.connect(db_path, isolation_level=None, timeout=10)
            cursor = co.cursor()
            cursor.execute("SELECT * FROM parcelle")
        except Exception as err:
            self.err.text =  'Local database error'
            print(err)
        else:
            rows = cursor.fetchall()
            tab = []
            for row in rows:
                ligne = [row[0],row[1],row[2],row[3],row[4],row[5],row[6]]
                tab.append(ligne)
            #print(tab)
            matricule = self.manager.get_screen("connexion").ids.matInput.text
            sr = SenderReceiver()
            result=sr.send(tab, matricule)
            self.err.text = result
            print(result)

    def PopupConf(self, order):
        if order == "open":
            self.confirmPopup.open()
            print("opening modal")
        elif order == "close":
            self.confirmPopup.dismiss()
            print("closing modal")
    
    # def Sync(self):
    #     sr = SenderReceiver()
    #     result=sr.sync()
    #     self.manager.transition.direction = 'up'
    #     self.manager.current = 'connexion'

    def on_leave(self, *args):
        self.err.text = ""
        return super().on_leave(*args)


class AjoutParcelle(MDScreen):#___________________________________________________________________________/\
    def __init__(self, *args, **kwargs):
        super(AjoutParcelle, self).__init__(*args, **kwargs)
    
    def on_pre_enter(self, *args):
        matricule = self.manager.get_screen("connexion").ids.matInput.text
        self.matriculeLabel.text = 'mat: '+matricule
        try:
            co = sqlite3.connect(db_path, isolation_level=None, timeout=10)
            cursor = co.cursor()
            cursor.execute("SELECT * FROM culture")
        except Exception as err:
            print(err)
        else:
            rows = cursor.fetchall()
            array = []
            for row in rows:
                strRow = row[1]+"("+row[0]+")"
                array.append(strRow)
            self.selectCulture.values = array
        return super().on_pre_enter(*args)
    
    def ajoutParcelle(self):
        numP = self.numParInput.text
        numE = self.numExploit.text
        rA = self.rendementA.text
        rP = self.rendementP.text
        surf = self.surface.text
        cult = self.selectCulture.text
        if re.search(r'\((.*?)\)',cult) !=None:
           cult = re.search(r'\((.*?)\)',cult).group(1)
        if numP == "" or numE == "" or rA == "" or rP == "" or surf == "" or cult == "Culture":
            self.formRes.color = 1,0,0,1
            self.formRes.text = "Veuillez remplir tout les champs"
        elif re.search(r"^([A-Z]|[0-9]){5}$",numE) ==None:
            self.formRes.color = 1,0,0,1
            self.formRes.text = "Format code d'exploitation incorrect"
        else:
            currentYear = datetime.now().year
            currentMonth = datetime.now().month
            if currentMonth > 6:
                scndYear = currentYear + 1
                annee = str(currentYear)+"-"+str(scndYear)
            else:
                scndYear = currentYear - 1
                annee = str(scndYear)+"-"+str(currentYear)
            co = sqlite3.connect(db_path, isolation_level=None, timeout=10)
            cursor = co.cursor()
            cursor.execute("SELECT COUNT(*) FROM parcelle WHERE id="+str(numP)+" AND idAnnee='"+annee+"' AND codeExploitation='"+numE+"'")
            count = cursor.fetchone()
            if count[0] == 0:
                try:
                    print("ajout")
                    co = sqlite3.connect(db_path, isolation_level=None, timeout=10)
                    cursor = co.cursor()
                    cursor.execute("INSERT INTO parcelle(id, idAnnee, codeExploitation, surface, rendementPrevu, rendementRealise, codeCulture) VALUES ("+str(numP)+",'"+annee+"','"+numE+"',"+str(surf)+","+str(rP)+","+str(rA)+",'"+cult+"')")
                except Exception:
                    self.formRes.color = 1,0,0,1
                    self.formRes.text = str("Parcelle existante ou type non conforme")
                else:
                    cursor.close()
                    self.formRes.color = 0,1,0.2,1
                    self.formRes.text = "Parcelle saisie"
                    self.clear()
            else:
                try:
                    co = sqlite3.connect(db_path, isolation_level=None, timeout=10)
                    cursor = co.cursor()
                    cursor.execute("UPDATE parcelle SET surface="+str(surf)+",rendementPrevu="+str(rP)+",rendementRealise="+str(rA)+",codeCulture='"+cult+"' WHERE id="+str(numP)+" AND idAnnee='"+annee+"' AND codeExploitation='"+numE+"'")
                except Exception as err:
                    self.formRes.color = 1,0,0,1
                    self.formRes.text = str("Parcelle existante ou type non conforme")
                else:
                    cursor.close()
                    self.formRes.color = 0,1,0.2,1
                    self.formRes.text = "Parcelle saisie"
                    self.clear()

    def backToAccueil(self):
        self.manager.current = 'accueil'

    def clear(self):
        self.numParInput.text = ""
        self.numExploit.text = ""
        self.rendementA.text = ""
        self.rendementP.text = ""
        self.surface.text = ""
        self.selectCulture.text = "Culture"

    def on_leave(self, *args):
        self.clear()
        self.formRes.text = ""
        return super().on_leave(*args)

    #def select_func(self, value):


class Agricolo(MDApp):
    def __init__(self, default_config=None, **kwargs):                                              
        super().__init__(**kwargs)
        # Instantiate the class with your necessary function and store it as a member of your MyApp instance.
        #Accueil.Envoie = staticmethod(Accueil.Envoie)

    def build(self):
        self.icon = "logo.png"
        screen_manager = MDScreenManager()
        screen_manager.add_widget(LoginTech(name ="connexion"))
        screen_manager.add_widget(Accueil(name ="accueil"))
        screen_manager.add_widget(AjoutParcelle(name ="ajoutP"))
        self.acc = screen_manager.get_screen("accueil")
        return screen_manager
    

#TESTS========================================================================================================
class test():
    def testConnect(self, matTest, mdpTest):
        matReg = re.search(r"^([A-Z]|[0-9]){5}$", matTest)
        mdpReg = re.search(r"(\'|\"|\`)+", mdpTest)
        if matReg != None:
            if mdpReg == None and mdpTest != '' and mdpTest != None:
                conn = sqlite3.connect(db_path, isolation_level=None, timeout=10)
                try:
                    stmt = conn.execute("SELECT id,mdp FROM technicien WHERE matricule= '"+matTest+"';")
                except sqlite3.DatabaseError as err:
                    print(err)
                else:
                    user = stmt.fetchone()
                    if user != None:
                        mdpUser = user[1]
                        if self.check_password(mdpTest, mdpUser):
                            err = "aucune"
                        else:
                            err = "mot de passe erroné"
                    else:
                        err = "matricule inconnu"
                    conn.close()
            else:
                err = "Format mdp incorrect"
        else:
            err = "matricule incorrect"
        print("matricule: "+matTest+" mdp: "+mdpTest+" erreur: "+err)
        return True

    def get_hashed_password(self, plain_text_password):
    # Hash a password for the first time
    #   (Using bcrypt, the salt is saved into the hash itself)
        return bcrypt.hashpw(plain_text_password.encode('utf-8'), bcrypt.gensalt())

    def check_password(self, plain_text_password, hashed_password):
        # Check hashed password. Using bcrypt, the salt is saved into the hash itself
        return bcrypt.checkpw(plain_text_password.encode('utf-8'), hashed_password.encode('utf-8'))
    
    def testAjoutParcelle(self, numParcelle, numExploitation, rendementPrevu, rendementFinal, surface, culture):
        #partie date================
        currentYear = datetime.now().year
        currentMonth = datetime.now().month
        if currentMonth > 6:
            scndYear = currentYear + 1
            annee = str(currentYear)+"-"+str(scndYear)
        else:
            scndYear = currentYear - 1
            annee = str(scndYear)+"-"+str(currentYear)
        #partie date================fin
        co = sqlite3.connect(db_path, isolation_level=None, timeout=10)
        cursor = co.cursor()
        cursor.execute("SELECT COUNT(*) FROM parcelle WHERE id="+str(numParcelle)+" AND idAnnee='"+annee+"' AND codeExploitation='"+numExploitation+"'")
        count = cursor.fetchone()
        if count[0] == 0:
            try:
                co = sqlite3.connect(db_path, isolation_level=None, timeout=10)
                cursor = co.cursor()
                cursor.execute("INSERT INTO parcelle(id, idAnnee, codeExploitation, surface, rendementPrevu, rendementRealise, codeCulture) VALUES ("+str(numParcelle)+",'"+annee+"','"+numExploitation+"',"+str(surface)+","+str(rendementPrevu)+","+str(rendementFinal)+",'"+culture+"')")
            except Exception:
                self.formRes.color = 1,0,0,1
                self.formRes.text = str("Parcelle existante ou type non conforme")
            else:
                cursor.close()
                self.formRes.color = 0,1,0.2,1
                self.formRes.text = "Parcelle saisie"
                self.clear()
        else:
            try:
                co = sqlite3.connect(db_path, isolation_level=None, timeout=10)
                cursor = co.cursor()
                cursor.execute("UPDATE parcelle SET surface="+str(surface)+",rendementPrevu="+str(rendementPrevu)+",rendementRealise="+str(rendementFinal)+",codeCulture='"+culture+"' WHERE id="+str(numParcelle)+" AND idAnnee='"+annee+"' AND codeExploitation='"+numExploitation+"'")
            except Exception as err:
                self.formRes.color = 1,0,0,1
                self.formRes.text = str("Parcelle existante ou type non conforme")
            else:
                cursor.close()
                self.formRes.color = 0,1,0.2,1
                self.formRes.text = "Parcelle saisie"
                self.clear()

    
application = Agricolo()
application.run()