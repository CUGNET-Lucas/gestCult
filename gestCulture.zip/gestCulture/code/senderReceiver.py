import http.client as Httplib
import json
import sqlite3
import os.path
from kivy.utils import platform

if platform != 'android' and platform != 'ios' :
    db_path = 'baseSQLite.db'
    ip="127.0.0.1"
else:
    package_dir = os.path.abspath(os.path.dirname(__file__))
    db_path = os.path.join(package_dir, 'baseSQLite.db')
    ip="192.168.72.22"

class SenderReceiver():
    def __init__(self) -> None:
        pass

    def send(self, array, matricule):
        if array != None:
            try:
                conn = Httplib.HTTPConnection(ip, 80, timeout=10)
            except Exception as error:
                print(error)
                return "Connection error"
            else:
                headers = {"charset" : "utf-8",'Content-type': 'application/json'}
                sampleJson = json.dumps(array, ensure_ascii = 'False')
                # Send the JSON data as-is -- we don't need to URL Encode this
                try:
                    conn.request("POST", "/agricolo/insert.php?mat="+matricule, sampleJson, headers)
                except Exception as error:
                    #print(error)
                    return "Connection error"
                else:
                    response = conn.getresponse()
                    #print(str(response.status)+" "+response.reason)
                    #ret = response.status+response.reason
                    #print(str(response.read().decode('utf-8')))
                    result = str(response.read().decode('utf-8'))
                    conn.close()
                    if result == "success":
                        co = sqlite3.connect(db_path, isolation_level=None, timeout=10)
                        cursor = co.cursor()
                        cursor.execute("DELETE FROM parcelle")
                        cursor.close()
                        return "Data sent"
                    elif result == "matriculeInexistant": 
                        return "incorrect matricul"
                    # elif result == "codeExploitError": 
                    #     return "incorrect eploitation code"
                    else:
                        return "Internal server error, contact your admin"