<?php

require("connex_cls.php");

$connex = new Connexion();
$conn=$connex->connect();

$matricule = $_GET["mat"];

// Load the POST.
$data = file_get_contents("php://input");

// ...and decode it into a PHP array.
$datas = json_decode($data);
$rs = array();
try{
    $stmt = $conn->prepare("SELECT id, COUNT(*) FROM technicien WHERE matricule='".$matricule."'");
    $stmt->execute();
    $reqTech = $stmt->fetch();
    // print_r($ct["COUNT(*)"]);
    // print_r($ct["id"]);
    if ($reqTech["COUNT(*)"] != 0 && $reqTech != null){
        $ct = $reqTech["COUNT(*)"];
        $idTechnicien = $reqTech["id"];
    }
}
catch (Exception $e) {
    print_r($e);
}
// --------------------------------------------------------------VERIFICATION EXISTENCE DES EXPLOITATIONS-----------
// foreach($datas as $row):
//     try{
//         $stmt = $conn->prepare("SELECT COUNT(*) FROM exploitation WHERE code=".$row[0]);
//         $stmt->execute();
//     }
//     catch(Exception $e){
//         print_r($e);
//     }
//     $ct = $stmt->fetch();
//     if ($ct[0] =< 0){
//         print_r("codeExploitError");
//     }
// endforeach;------------------------------------------------------------------------------------------------------

if($reqTech["COUNT(*)"] == 1 && $reqTech != null ){
    $exploitTable = array();
    foreach($datas as $row):
        if (!in_array( $row[0] ,$exploitTable)){
            array_push($exploitTable, $row[0]);
        }
        try{
            $stmt = $conn->prepare("INSERT INTO parcelle (`codeExploitation`, `idAnnee`, `id`, `surface`, `rendementPrevu`, `rendementRealise`, `codeCulture`) VALUES('".$row[0]."', '".$row[1]."', '".$row[2]."','".$row[3]."', '".$row[4]."', '".$row[5]."', '".$row[6]."');");
            $stmt->execute();
            //print_r("INSERT INTO parcelle (`codeExploitation`, `idAnnee`, `id`, `surface`, `rendementPrevu`, `rendementRealise`, `codeCulture`) VALUES('".$row[0]."', '".$row[1]."', '".$row[2]."','".$row[3]."', '".$row[4]."', '".$row[5]."', '".$row[6]."');");
        }
        catch (Exception $e) {
            //print_r($e);
        }
    endforeach;
    //print_r($exploitTable);
    foreach($exploitTable as $exploitation):
        try{
            $stmt = $conn->prepare("INSERT INTO `controler`(`idTechnicien`, `codeExploitation`, `idAnnee`) VALUES ('".$idTechnicien."','".$exploitation."','".$row[1]."');");
            $stmt->execute();
            //print_r("INSERT INTO `controler`(`idTechnicien`, `codeExploitation`, `idAnnee`) VALUES ('".$idTechnicien."','".$exploitation."','".$row[1]."');");
        }catch (Exception $e) {
            //print_r($e);
        }
    endforeach;
    print_r("success");
}else{
    print_r("matriculeInexistant");
}

?>