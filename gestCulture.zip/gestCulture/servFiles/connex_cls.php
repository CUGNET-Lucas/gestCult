<?php
	class Connexion
	{

	//Attributs
		private $connex;
		
	//Constructeur
		function __construct(){}

	//Méthodes	
		function connect(){
			try
			{
				//$connexion = new PDO('mysql:host=localhost;dbname=ttpm23;charset=utf8', 'ttpm23', 'BdR875L');
				$connexion = new PDO("mysql:host=localhost;dbname=agricolo","root","");
			}
			catch(Exception $e)
			{
				// En cas d'erreur, on affiche un message et on arrête tout
				die('Erreur : '.$e->getMessage());
			}
			$this->connex = $connexion;
			return $this->connex;
		}
	}
?>
